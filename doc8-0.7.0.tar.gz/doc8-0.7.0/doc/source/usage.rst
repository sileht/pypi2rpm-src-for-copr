=====
Usage
=====

To use doc8 in a project::

    import doc8
