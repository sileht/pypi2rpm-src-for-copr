`hello`__ world

.. _hello: http://github.com/
