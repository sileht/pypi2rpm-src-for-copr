`Fork me on GitHub <https://github.com/evvers/git-pre-commit-hook`_
